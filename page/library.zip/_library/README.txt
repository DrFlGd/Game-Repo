Game Repo

This folder is a library for the Game Repo desktop app. The app keeps its own
files in this _library folder; your games stay ordinary files, in the folders
beside it or wherever you keep them, so the library can be moved, copied or
synced and opened again by any version of the app.

_library/library.json   the library's name and settings
_library/games/         each game's details, scraped pictures and your documents
_library/dats/          the DAT files you imported, by platform and version
_library/journal/       the moves and renames the app made, so they can be undone

The app's index of your files is kept on each computer, not here, and is made
again from these files when it's missing.
