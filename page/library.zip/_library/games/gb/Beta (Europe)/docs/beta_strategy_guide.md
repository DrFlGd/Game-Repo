# Beta strategy

Always go **left** at the second fork.